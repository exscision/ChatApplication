﻿using MyFirstChatApplication;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChatApplication
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////
        /// Events
        ///////////////////////////////////////////////////////////////////////////////////////////////
        private void btnRegister_Click(object sender, EventArgs e)
        {

            // checks the email being registered, 
            // to verify that it is an appropriate email
            // by calling the IsValidEmail() Method, using the
            // Email text as a parameter.
            if (IsValidEmail(txtEmail.Text) == true)
            {

                // Creates a new list of SQL Parameters
                List<SqlParameter> sqlParams = new List<SqlParameter>();

                // SQL Parameters being defined
                SqlParameter param1 = new SqlParameter("@email", txtEmail.Text.Trim());
                SqlParameter param2 = new SqlParameter("@password", txtPass.Text.Trim());
                //SqlParameter param3 = new SqlParameter("@Date", DateTime.Now);
                SqlParameter param3 = new SqlParameter("@firstName", txtFirst.Text.Trim());
                SqlParameter param4 = new SqlParameter("@lastName", txtLast.Text.Trim());

                // Verifies an Email and a password have been chosen
                // for the registration; 
                if (txtEmail.Text != "" || txtPass.Text != "")
                {
                    // adds the username(email) parameter
                    sqlParams.Add(param1);

                    // executes a stored procedure to verify the user being registered
                    // isn't a duplicate
                    DataTable dt = DAL.ExecStoredProcedure("VerifyEmail", sqlParams);

                    // if the data contains information
                    if (dt.Rows.Count != 0)
                    {
                        // user is a duplicate
                        MessageBox.Show("Email Already Exists!");
                    }
                    else
                    {
                        // add password and time parameters
                        sqlParams.Add(param2);
                        sqlParams.Add(param3);
                        sqlParams.Add(param4);

                        // executes the "register" store procedure. This adds a new user to the
                        // database; using the Username, Email, and current time
                        DAL.ExecStoredProcedure("CreateUser", sqlParams);

                        // Verifies registration has been completed.
                        MessageBox.Show("Registration Complete.");

                        // Sends an email to the user that registered. Confirming their registration
                        RegistrationEmail();
                        // clears the parameter list
                        sqlParams.Clear();
                        Close();
                    }
                }
                else
                {
                    // asks the user for an email and password if one or both are missing
                    MessageBox.Show("Please input a Email and Password");

                }
            }
            else
            {
                // requests a valid email for registration
                MessageBox.Show("Please enter a Email Address");
                // clears the email textbox
                txtEmail.Clear();
                // sets focus to the email textbox
                txtEmail.Focus();
            }
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////
        /// End of Events
        ///////////////////////////////////////////////////////////////////////////////////////////////



        ///////////////////////////////////////////////////////////////////////////////////////////////
        /// Methods
        ///////////////////////////////////////////////////////////////////////////////////////////////
        public bool IsValidEmail(string email)
        {
            // attempts to convert the input text as an email; returns a true or false value
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }


        public void RegistrationEmail()
        {
            {
                try
                {
                    // Creates a new email to be sent based on the email address that was registered
                    MailMessage mail = new MailMessage();
                    // sets the mail protocol
                    SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
                    // The email that is sending the email
                    mail.From = new MailAddress("zachysorrow@gmail.com");
                    // the email address recieving the message
                    mail.To.Add(txtEmail.Text);
                    // Subject of the email
                    mail.Subject = "Chat App - Registration";
                    // The body of the email being sent( Contains a thank you message, and the username and password that was created.
                    mail.Body = "Thank you for Registering for Chat App! Please keep this information:      Username: " + txtEmail.Text + " and Password: " + txtPass.Text + ".";
                    // sets the smtp port being used. Default is 587
                    SmtpServer.Port = 587;
                    // the email account that is sending the email; the secure loging is required
                    SmtpServer.Credentials = new System.Net.NetworkCredential("zachysorrow@gmail.com", "fu3hs5nk");
                    // enables a secure connection
                    SmtpServer.EnableSsl = true;
                    // sends an email
                    SmtpServer.Send(mail);
                }
                catch (Exception ex)
                {

                }

            }
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////
        /// End of Methods
        ///////////////////////////////////////////////////////////////////////////////////////////////


    }
}
