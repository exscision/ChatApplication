﻿using MyFirstChatApplication;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.NetworkInformation;
using System.Windows.Forms;

namespace ChatApplication
{
    public partial class Form1 : Form
    {
        /// Zachary White
        /// Chat Program

        public Form1()
        {
            // initializes the form components
            InitializeComponent();
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////
        /// Methods
        ///////////////////////////////////////////////////////////////////////////////////////////////
        private void AttemptLogin()
        {
            // verifies that data has been placed within the text boxes
            // for the username(Email) and Password
            if (txtEmail.Text != "" && txtPassword.Text != "")
            {
                // Creates a new list for SQL Parameters
                List<SqlParameter> sqlParams = new List<SqlParameter>();

                // creates parameters
                SqlParameter param1 = new SqlParameter("@email", txtEmail.Text.Trim());
                SqlParameter param2 = new SqlParameter("@password", txtPassword.Text.Trim());

                // adds the parameters
                sqlParams.Add(param1);
                sqlParams.Add(param2);

                // fills a datatable with the " CheckPassword " stored procedure
                // results. 
                DataTable dt = DAL.ExecStoredProcedure("Login", sqlParams);

                // if the datatable contains rows; 
                if (dt.Rows.Count != 0)
                {
                    // Calls the Login() Method
                    Login();
                    // Changes the title of the Form
                    this.Text += txtEmail.Text.Trim();
                }
                else
                {
                    // Generates a message box stating that either the
                    // username and password is incorrect based on the
                    // account that was registered.
                    MessageBox.Show("Incorrect Email or Password");
                }
            }
            else
            {
                // if either textbox is empty; outputs a message
                // asking the user to input an email and password
                MessageBox.Show("Please input a Email and Password");
            }
        }


        public void Login()
        {
            // Manipulates the form; when logged in, hides aspects that aren't required,
            // and brings all required aspects to a true visibility state.
            MessageBox.Show("Welcome! You've been logged in.");
            string emailLogged = txtEmail.Text;
            string passwordLogged = txtPassword.Text;
            txtEmail.Visible = false;
            txtPassword.Visible = false;
            btnRegister.Visible = false;
            btnLogin.Visible = false;
            btnSignOff.Visible = true;
            txtSend.Visible = true;
            btnSend.Visible = true;
            lblEmail.Visible = false;
            lblPass.Visible = false;
            timeRefresh.Enabled = true;
            btnRefresh.Visible = true;
            txtSend.Focus();
            // Calls the RefreshMessages() method
            RefreshMessages();
            // Changes the "enter" key.
            this.AcceptButton = btnSend;
        }


        public void RefreshMessages()
        {
            //int id = UserId();
            // Clears the text box
            txtMessages.Clear();
            //new data table
            DataTable messages = new DataTable();
            //list used for the user parameters
            List<SqlParameter> userid = new List<SqlParameter>();
            //fills the messages data table with information from the TopMessages Procedure
            messages = DAL.ExecStoredProcedure("TopMessages");
            //new data table
            DataTable user = new DataTable();
            //fills the user table with information about the userid
            user = DAL.ExecStoredProcedure("userInfo", userid);
            //variables
            int msgrow = 0;
            int uid = 0;
            //for each row in the messages table
            foreach (var x in messages.Rows)
            {
                //uid :: references the user ID
                uid = Convert.ToInt32(user.Rows[msgrow][0]);
                msgrow = 0;
                // while the msgrow counter is less than the count of the messages rows
                while (msgrow <= messages.Rows.Count - 1)
                {
                    uid = 0;
                    //while the uid counter is less than the count of the user table
                    while (uid <= user.Rows.Count - 1)
                    {
                        //if the user ID == the messages.UserId
                        if (user.Rows[uid]["Id"].ToString() == messages.Rows[msgrow]["UserId"].ToString())
                        {

                            //the name is equal to the first name + the last name. 
                            var name = user.Rows[uid]["First"].ToString() + " " + user.Rows[uid]["Last"].ToString();
                            // conversts the tables "created" date to a datetimeoffset.
                            DateTimeOffset time = new DateTimeOffset(Convert.ToDateTime((messages.Rows[msgrow]["Created"]).ToString()));  
                            //defines the messages content (the message) 
                            var text = messages.Rows[msgrow]["Content"].ToString();
                            // outputs the data that was sent as a message
                            // in the text box containing the "chat"
                            txtMessages.Text += "[" + name + "]" + "< " + time + " >: " + text + Environment.NewLine;
                            //txtMessages.Text += Environment.NewLine;
                        }
                        //increment the userid
                        uid++;
                    }
                    //increment the msgrow
                    msgrow++;
                }
                //breaks out of the loops.
                break;
            }
        }


        public void SendMessages()
        {
            int userId = UserId();
            // Gets the MacAddress // Machine ID of the machine that messages
            // are being delivered sent to the database from
            var macAddr =
                (
                    from nic in NetworkInterface.GetAllNetworkInterfaces()
                    where nic.OperationalStatus == OperationalStatus.Up
                    select nic.GetPhysicalAddress().ToString()
                ).FirstOrDefault();

            // adds scrollbars to the textbox for "Messages"
            // txtMessages.ScrollBars = ScrollBars.Vertical;

            // If a blank message is being sent; data will not be sent and the
            // textbox will recieve focus
            if (txtSend.Text == "")
            {
                txtSend.Focus();
            }
            else
            {
                // generates a list of parameters
                List<SqlParameter> messageList = new List<SqlParameter>();
                List<SqlParameter> addMac = new List<SqlParameter>();

                // designates the parameters and their controls.
                SqlParameter param1 = new SqlParameter("@userId", userId);
                SqlParameter param2 = new SqlParameter("@content", txtSend.Text.Trim());
                SqlParameter param3 = new SqlParameter("@mac", macAddr);
                SqlParameter param4 = new SqlParameter("@Id", userId);

                addMac.Add(param3);
                addMac.Add(param4);


                // adds the parameters to the list
                messageList.Add(param1);
                messageList.Add(param2);
                //messageList.Add(param3);

                DataTable log = new DataTable();
                DAL.ExecStoredProcedure("InsertMessage", messageList);
                DAL.ExecStoredProcedure("insertMac", addMac);
                // Clears the Textbox
                txtSend.Clear();
                // Calls the RefreshMessages() Method
                RefreshMessages();
                // Sets focus to the 
                txtSend.Focus();
            }
        }


        public int UserId()
        {
            int id;

            // Creates a new list of SQL Parameters
            List<SqlParameter> sqlParams = new List<SqlParameter>();

            // SQL Parameters being defined
            SqlParameter param1 = new SqlParameter("@email", txtEmail.Text.Trim());
            sqlParams.Add(param1);

            DataTable user = new DataTable();


            user = DAL.ExecStoredProcedure("verifyEmail", sqlParams);

            id = Convert.ToInt32(user.Rows[0][1]);

            return id;
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////
        /// End of Methods
        ///////////////////////////////////////////////////////////////////////////////////////////////




        ///////////////////////////////////////////////////////////////////////////////////////////////
        /// Events
        ///////////////////////////////////////////////////////////////////////////////////////////////
        private void btnSend_Click(object sender, EventArgs e)
        {
            SendMessages();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            // Calls the RefreshMessages() Method
            RefreshMessages();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            AttemptLogin();
        }

        private void btnSignOff_Click(object sender, EventArgs e)
        {
            // Message to the user
            MessageBox.Show("Thank you, See you again soon!");
            // Closes the program
            Close();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            Register Registration = new Register();
            Registration.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // modifies the "enter" key
            this.AcceptButton = btnLogin;
            // sets focus to the email textbox.
            txtEmail.Focus();
        }

        private void txtEmail_Enter(object sender, EventArgs e)
        {
            // removes content from the textbox when the user clicks it
            if (txtEmail.Text == "Please enter an Email Address")
            {
                txtEmail.Text = "";
            }
        }

        private void txtEmail_Leave(object sender, EventArgs e)
        {
            // fills the email textbox if there's nothing in it, when the user
            // clicks something else
            if (txtEmail.Text == "")
            {
                txtEmail.Text = "Please enter an Email Address";
            }
        }

        private void txtPassword_Enter(object sender, EventArgs e)
        {
            // removes all data in the password text box
            txtPassword.Text = "";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            // Calls the RefreshMessages()
            RefreshMessages();
        }

        private void txtMessages_TextChanged(object sender, EventArgs e)
        {
            txtMessages.ScrollBars = ScrollBars.Vertical;
            txtMessages.SelectionStart = txtMessages.TextLength;
            txtMessages.ScrollToCaret();
        }


        ///////////////////////////////////////////////////////////////////////////////////////////////
        /// End of Events
        ///////////////////////////////////////////////////////////////////////////////////////////////
    }
}


