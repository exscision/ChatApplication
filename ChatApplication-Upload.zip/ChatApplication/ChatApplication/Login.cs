﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using ChatApplication;
using MyFirstChatApplication;
using System.Windows.Forms;

namespace ChatApplication
{
    public static partial class Login
    {

    }
}
